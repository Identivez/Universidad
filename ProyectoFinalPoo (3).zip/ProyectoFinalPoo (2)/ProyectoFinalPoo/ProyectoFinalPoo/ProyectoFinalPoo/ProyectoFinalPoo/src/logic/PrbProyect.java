/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package logic;
import ugi.menu;
import ugi.ca;


public class PrbProyect 
{

    
    public static void main(String[] args)
    {
       menu m= new menu();
       m.setVisible(true);
        m.setUndecorated(true);
        initComponents();
        m.setLocationRelativeTo(null);
        
        
        
        
    }

    private static void initComponents()
    {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   

}
